const { Sequelize } = require('sequelize');
const config = require('../config/config');
const User = require('./userModel');

// Inicialize o Sequelize
const sequelize = new Sequelize(config.development);

// Teste a conexão
async function testConnection() {
  try {
    await sequelize.authenticate();
    console.log('Connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

testConnection();

// Importa todos os modelos
const models = {
  User: User(sequelize, Sequelize.DataTypes), // Passa o sequelize e DataTypes ao modelo
};

// Sincroniza os modelos com o banco de dados
async function syncModels() {
  try {
    await sequelize.sync({ force: false }); // Altere para { force: true } se quiser recriar as tabelas
    console.log('Database & tables created!');
  } catch (error) {
    console.error('Error creating tables:', error);
  }
}

syncModels();

module.exports = { sequelize, models };
