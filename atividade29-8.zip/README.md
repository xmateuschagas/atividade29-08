# Node + Express Service Starter

This is a simple hello world express.js server.

## Getting Started

Previews should run automatically when starting a workspace. Run the `Show Web Preview` IDX command to see the preview.